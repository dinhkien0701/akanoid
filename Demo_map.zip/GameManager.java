import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

class GameManager {

  int width, height;
  GraphicsContext gc;
  Main.GameState gameState = Main.GameState.READY;
  Paddle paddle;
  Ball ball;
  List<Brick> bricks = new ArrayList<>();
  boolean pressedLeft = false, pressedRight = false;
  Rectangle map;

  GameManager(int width, int height, Rectangle map, GraphicsContext gc) {
    this.width = width;
    this.height = height;
    this.gc = gc;
    this.map = map;
    initLevel();
  }

  void initLevel() {
    paddle = new Paddle(map.width / 2 - 60 + map.x, map.height - 40 + map.y, 100, 16);

    ball = new Ball(map.width / 2 - 60 + map.x + 50 - 8, map.height - 40 + map.y - 16, 5);
    bricks.clear();


    int rows = 8, cols = 8;
    int[][] arr = {
        {2, 2, 0, 0, 0, 0, 2, 2}, // hàng 0
        {2, 0, 0, 0, 0, 0, 0, 2}, // hàng 1
        {0, 0, 0, 0, 0, 0, 0, 0}, // hàng 2
        {0, 0, 0, 1, 1, 0, 0, 0}, // hàng 3
        {0, 0, 0, 1, 1, 0, 0, 0}, // hàng 4
        {0, 0, 0, 0, 0, 0, 0, 0}, // hàng 5
        {2, 0, 0, 0, 0, 0, 0, 2}, // hàng 6
        {2, 2, 0, 0, 0, 0, 2, 2}  // hàng 7
    };

    double brickW = (map.width - 60) / cols;
    double brickH = 20;

    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
          if(arr[r][c] == 0){
            continue;
          } else {
            double bx = 30 + c * brickW + map.x;
            double by = 50 + r * (brickH + 6) + map.y;
            if(arr[r][c] == 1) {
              bricks.add(new NormalBrick(bx, by, brickW - 6, brickH));
            } else {
              bricks.add(new EternalBrick(bx, by, brickW - 6, brickH));
            }
          }
      }
    }
    gameState = Main.GameState.READY;
  }

  void startGame() {
    gameState = Main.GameState.RUNNING;
  }

  void reset() {
    initLevel();
  }

  void onBallLost() {
    gameState = Main.GameState.GAMEOVER;
  }

  void update() {
    if (pressedLeft) {
      paddle.moveLeft();
    } else if (pressedRight) {
      paddle.moveRight();
    } else {
      paddle.stop();
    }
    if (gameState == Main.GameState.RUNNING) {
      paddle.update(this);
      ball.update(this);
      if (ball.checkCollision(paddle) != Ball.BallCollusion.NONE) {
        ball.bounceOff(paddle, ball.checkCollision(paddle));
        ball.y = paddle.y - ball.height - 1;
      }
      Iterator<Brick> it = bricks.iterator();
      while (it.hasNext()) {
        Brick b = it.next();
        if (ball.checkCollision(b) != Ball.BallCollusion.NONE) {
          b.takeHit();
          ball.bounceOff(b , ball.checkCollision(b));
          if (b.isDestroyed()) {
            it.remove();
          }
          //break;
        }
      }
      if(bricks.isEmpty()){
        gameState = Main.GameState.GAMEOVER;
      }
    }
  }

  void render() {
    gc.setFill(Color.BLACK);
    gc.fillRect(0, 0, width, height);
    gc.setFill(Color.GREEN);
    gc.fillRect(map.x, map.y, map.width, map.height);
    for (Brick b : bricks) {
      b.render(gc);
    }
    paddle.render(gc);
    ball.render(gc);
    gc.setFill(Color.WHITE);
    gc.fillText("State: " + gameState.name() + "    Press SPACE to start/reset", 10, 20);
  }
}